package com.example.mytapsaver

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val etTarget = findViewById<EditText>(R.id.etTarget)
        val btnSave = findViewById<Button>(R.id.btnSave)

        val prefs = getSharedPreferences("mytap_prefs", MODE_PRIVATE)
        val currentTarget = prefs.getLong("targetAmount", 1000L)
        etTarget.setText(currentTarget.toString())

        btnSave.setOnClickListener {
            val newTarget = etTarget.text.toString().toLongOrNull() ?: 0L
            prefs.edit().putLong("targetAmount", newTarget).apply()
            finish()
        }
    }
}
