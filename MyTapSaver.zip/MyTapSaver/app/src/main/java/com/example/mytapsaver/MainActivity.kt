package com.example.mytapsaver

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var targetAmount = 0L
    private var currentAmount = 0L
    private var perTap = 10L

    private lateinit var tvTarget: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var tvRemaining: TextView
    private lateinit var spinnerAmount: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("mytap_prefs", MODE_PRIVATE)

        tvTarget = findViewById(R.id.tvTarget)
        tvCurrent = findViewById(R.id.tvCurrent)
        tvRemaining = findViewById(R.id.tvRemaining)
        spinnerAmount = findViewById(R.id.spinnerAmount)

        targetAmount = prefs.getLong("targetAmount", 1000L)
        currentAmount = prefs.getLong("currentAmount", 50L)
        perTap = prefs.getLong("perTap", 10L)

        updateUI()

        val amounts = arrayOf(5L, 10L, 20L, 50L)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, amounts)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerAmount.adapter = adapter
        val index = amounts.indexOf(perTap).let { if (it >= 0) it else 0 }
        spinnerAmount.setSelection(index)
        spinnerAmount.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>, view: View?, position: Int, id: Long) {
                perTap = amounts[position]
                prefs.edit().putLong("perTap", perTap).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>) {}
        })

        val circle = findViewById<View>(R.id.circleContainer)
        circle.setOnClickListener {
            startTapSequence()
        }

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun startTapSequence() {
        val header = findViewById<View>(R.id.headerInfo)
        val spinnerRow = findViewById<View>(R.id.spinnerRow)
        header.visibility = View.INVISIBLE
        spinnerRow.visibility = View.INVISIBLE

        val fade = AlphaAnimation(1f, 0f)
        fade.duration = 150
        findViewById<View>(R.id.tvTapHint).startAnimation(fade)

        currentAmount += perTap
        prefs.edit().putLong("currentAmount", currentAmount).apply()

        Snackbar.make(findViewById(R.id.circleContainer), getString(R.string.added_msg, perTap.toInt()), Snackbar.LENGTH_SHORT).show()

        header.visibility = View.VISIBLE
        spinnerRow.visibility = View.VISIBLE
        updateUI()

        // TODO: sync with Firebase when signed in
        // FirebaseManager.syncAmounts(userId, currentAmount, targetAmount)
    }

    private fun updateUI() {
        tvTarget.text = getString(R.string.label_target) + "\n" + targetAmount
        tvCurrent.text = getString(R.string.label_current) + "\n" + currentAmount
        val remaining = (targetAmount - currentAmount).let { if (it > 0) it else 0L }
        tvRemaining.text = getString(R.string.label_remaining) + "\n" + remaining
    }
}
