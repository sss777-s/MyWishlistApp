package com.example.mytapsaver

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

object FirebaseManager {
    private val auth: FirebaseAuth = Firebase.auth
    private val db = FirebaseFirestore.getInstance()

    fun syncAmounts(userId: String, current: Long, target: Long) {
        val map = hashMapOf(
            "currentAmount" to current,
            "targetAmount" to target
        )
        db.collection("users").document(userId)
            .set(map)
            .addOnSuccessListener { /* saved */ }
            .addOnFailureListener { /* failed */ }
    }

    fun fetchAmounts(userId: String, callback: (Long, Long) -> Unit) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { doc ->
                val current = doc.getLong("currentAmount") ?: 0L
                val target = doc.getLong("targetAmount") ?: 0L
                callback(current, target)
            }
    }
}
